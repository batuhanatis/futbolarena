import React from 'react';
import { Player, Team } from '../types';
import { User, Copy, PlayCircle, ArrowRightLeft } from 'lucide-react';

interface LobbyProps {
  sessionId: string;
  players: Player[];
  teams: { A: Team, B: Team };
  onMovePlayer: (playerId: string, targetTeam: 'A' | 'B') => void;
  onStartGame: () => void;
  inviteLink: string;
}

const Lobby: React.FC<LobbyProps> = ({ sessionId, players, teams, onMovePlayer, onStartGame, inviteLink }) => {
  const teamAPlayers = players.filter(p => p.team === 'A');
  const teamBPlayers = players.filter(p => p.team === 'B');

  const copyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    alert("Davet linki kopyalandı!");
  };

  return (
    <div className="h-full bg-gray-900 p-8 overflow-y-auto flex flex-col items-center">
      <div className="w-full max-w-5xl">
        
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-display text-white mb-4">OTURUM: <span className="text-game-yellow">{sessionId}</span></h1>
          <div className="flex items-center justify-center gap-4">
             <div className="bg-gray-800 px-4 py-2 rounded text-gray-400 border border-gray-700 font-mono text-sm">
                {inviteLink}
             </div>
             <button onClick={copyLink} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded flex items-center gap-2 font-bold">
                <Copy size={16}/> Linki Kopyala
             </button>
          </div>
          <p className="text-gray-500 mt-4 text-sm">Bu linki yarışmacılara gönderin. Onlar katıldıkça aşağıda görünecekler.</p>
        </div>

        {/* Teams Container */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
           
           {/* Team A */}
           <div className="bg-blue-900/30 border-2 border-blue-600/50 rounded-xl p-6 relative">
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-6 py-2 rounded-full font-bold shadow-lg">
                {teams.A.name} ({teamAPlayers.length})
              </div>
              <div className="mt-6 space-y-2 min-h-[200px]">
                 {teamAPlayers.length === 0 && <div className="text-center text-blue-300/50 italic py-10">Oyuncu bekleniyor...</div>}
                 {teamAPlayers.map(player => (
                    <div key={player.id} className="bg-blue-800/50 p-3 rounded flex justify-between items-center group">
                       <div className="flex items-center gap-2">
                          <User size={18} className="text-blue-300"/>
                          <span className="font-bold text-white">{player.name}</span>
                       </div>
                       <button 
                         onClick={() => onMovePlayer(player.id, 'B')}
                         className="text-xs bg-gray-900 hover:bg-pink-600 text-gray-400 hover:text-white px-2 py-1 rounded flex items-center gap-1 transition"
                         title="Takım B'ye Taşı"
                       >
                         B'ye Taşı <ArrowRightLeft size={12}/>
                       </button>
                    </div>
                 ))}
              </div>
           </div>

           {/* Team B */}
           <div className="bg-pink-900/30 border-2 border-pink-600/50 rounded-xl p-6 relative">
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-pink-600 text-white px-6 py-2 rounded-full font-bold shadow-lg">
                {teams.B.name} ({teamBPlayers.length})
              </div>
              <div className="mt-6 space-y-2 min-h-[200px]">
                 {teamBPlayers.length === 0 && <div className="text-center text-pink-300/50 italic py-10">Oyuncu bekleniyor...</div>}
                 {teamBPlayers.map(player => (
                    <div key={player.id} className="bg-pink-800/50 p-3 rounded flex justify-between items-center group">
                       <div className="flex items-center gap-2">
                          <User size={18} className="text-pink-300"/>
                          <span className="font-bold text-white">{player.name}</span>
                       </div>
                       <button 
                         onClick={() => onMovePlayer(player.id, 'A')}
                         className="text-xs bg-gray-900 hover:bg-blue-600 text-gray-400 hover:text-white px-2 py-1 rounded flex items-center gap-1 transition"
                         title="Takım A'ya Taşı"
                       >
                         <ArrowRightLeft size={12}/> A'ya Taşı 
                       </button>
                    </div>
                 ))}
              </div>
           </div>

        </div>

        {/* Start Button */}
        <div className="flex justify-center">
           <button 
             onClick={onStartGame}
             className="bg-game-yellow text-black text-xl font-bold py-4 px-12 rounded-full shadow-[0_0_30px_rgba(250,204,21,0.4)] hover:bg-yellow-400 hover:scale-105 transition-all flex items-center gap-3"
           >
              <PlayCircle size={32}/> YARIŞMAYI BAŞLAT
           </button>
        </div>

      </div>
    </div>
  );
};

export default Lobby;