import React, { useState, useEffect } from 'react';
import { GameRound, Player } from '../types';
import { Hand, Send, CheckCircle2, Wifi, WifiOff } from 'lucide-react';
import { gameSync } from '../services/sync';

interface PlayerRemoteProps {
  sessionId: string;
  activeGame: GameRound | null;
  gamePhase: 'LOBBY' | 'GAME';
}

const generateSimpleId = () => {
  return 'player-' + Math.random().toString(36).substr(2, 9);
};

const PlayerRemote: React.FC<PlayerRemoteProps> = ({ sessionId, activeGame, gamePhase }) => {
  const [joined, setJoined] = useState(false);
  const [name, setName] = useState('');
  const [team, setTeam] = useState<'A' | 'B'>('A');
  // Use safe ID generation
  const [myId] = useState(() => {
     try {
       // Check if crypto exists and has randomUUID
       if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
         return crypto.randomUUID().slice(0, 6);
       }
       return generateSimpleId();
     } catch (e) {
       return generateSimpleId();
     }
  });
  
  // Numeric State
  const [numericInput, setNumericInput] = useState('');
  const [numericSubmitted, setNumericSubmitted] = useState(false);
  
  const [isOnline, setIsOnline] = useState(gameSync.getMode() === 'FIREBASE');

  useEffect(() => {
      setIsOnline(gameSync.getMode() === 'FIREBASE');
  }, []);

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    const player: Player = { id: myId, name: name.toUpperCase(), team };
    
    // Send to Host via Sync Service
    gameSync.sendEvent(sessionId, {
      type: 'PLAYER_JOIN',
      payload: player
    });

    setJoined(true);
  };

  const handleBuzzerClick = () => {
    gameSync.sendEvent(sessionId, { 
      type: 'BUZZ_CLICKED', 
      teamId: team, 
      playerId: myId, 
      playerName: name 
    });
  };

  const handleNumericSend = () => {
    if (!activeGame || !numericInput) return;
    
    gameSync.sendEvent(sessionId, { 
      type: 'NUMERIC_GUESS', 
      playerId: myId, 
      playerName: name, 
      team, 
      guess: parseInt(numericInput) 
    });

    setNumericSubmitted(true);
  };

  // Reset numeric state when game changes
  React.useEffect(() => {
    setNumericSubmitted(false);
    setNumericInput('');
  }, [activeGame?.id]);

  if (!joined) {
    return (
       <div className="h-full w-full bg-gray-900 p-6 flex flex-col items-center justify-center text-white relative">
          <div className="absolute top-4 right-4 flex items-center gap-2 text-xs font-mono opacity-50">
             {isOnline ? <Wifi size={14} className="text-green-500"/> : <WifiOff size={14} className="text-red-500"/>}
             {isOnline ? 'ONLINE' : 'LOCAL'}
          </div>

          <div className="w-full max-w-md bg-gray-800 p-8 rounded-xl shadow-xl border border-gray-700">
             <h1 className="text-center font-display text-3xl text-game-yellow mb-6">GİRİŞ YAP</h1>
             
             {!isOnline && (
                 <div className="bg-red-900/50 border border-red-500/50 p-3 rounded mb-4 text-xs text-red-200 text-center">
                    Bağlantı Hatası: Local moddasınız. Diğer cihazlar sizi göremez.
                 </div>
             )}

             <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-gray-700 p-3 rounded mb-4 text-center font-bold" placeholder="ADINIZ" />
             <div className="flex gap-4 mb-6">
                <button onClick={() => setTeam('A')} className={`flex-1 p-3 rounded font-bold ${team === 'A' ? 'bg-blue-600 ring-2 ring-white' : 'bg-blue-900'}`}>TAKIM A</button>
                <button onClick={() => setTeam('B')} className={`flex-1 p-3 rounded font-bold ${team === 'B' ? 'bg-pink-600 ring-2 ring-white' : 'bg-pink-900'}`}>TAKIM B</button>
             </div>
             <button onClick={handleJoinSubmit} className="w-full bg-green-600 py-4 rounded font-bold text-xl">KATIL</button>
          </div>
       </div>
    );
  }

  if (gamePhase === 'LOBBY' || !activeGame) {
     return (
        <div className="h-full bg-gray-900 flex flex-col items-center justify-center text-white relative">
            <div className="absolute top-4 right-4 flex items-center gap-2 text-xs font-mono opacity-50">
                {isOnline ? <Wifi size={14} className="text-green-500"/> : <WifiOff size={14} className="text-red-500"/>}
            </div>
            <p className="animate-pulse">Oyunun başlaması bekleniyor...</p>
            <div className="mt-4 text-gray-500 text-sm">{name} • {team === 'A' ? 'Takım A' : 'Takım B'}</div>
        </div>
     );
  }

  // --- NUMERIC INTERFACE ---
  if (activeGame.type === 'NUMERIC') {
     return (
        <div className="h-full bg-gray-900 p-6 flex flex-col items-center justify-center text-white relative">
           <div className="text-center mb-8">
              <span className="bg-yellow-600 text-black px-2 py-1 rounded text-xs font-bold">SAYISAL TAHMİN</span>
              <p className="mt-4 text-lg font-bold text-gray-300">Tahminini Gir ve Gönder!</p>
           </div>
           
           {!numericSubmitted ? (
              <div className="w-full max-w-sm space-y-4">
                 <input 
                   type="number" 
                   value={numericInput} 
                   onChange={e => setNumericInput(e.target.value)} 
                   className="w-full p-6 text-4xl text-center bg-gray-800 border-2 border-gray-600 rounded-xl outline-none focus:border-game-yellow text-white font-mono"
                   placeholder="0"
                 />
                 <button onClick={handleNumericSend} className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold text-xl flex items-center justify-center gap-2">
                    <Send size={24}/> GÖNDER
                 </button>
              </div>
           ) : (
              <div className="text-center animate-pop">
                 <div className="text-6xl text-green-500 mb-4"><CheckCircle2 size={80} className="mx-auto"/></div>
                 <h2 className="text-2xl font-bold">Tahmin Gönderildi!</h2>
                 <p className="text-gray-400 mt-2">Sonuçlar ekranda açıklanacak.</p>
              </div>
           )}
        </div>
     );
  }

  // --- BUZZER INTERFACE (FEUD & WORD) ---
  const isQuestionHidden = activeGame.type === 'FEUD' && !activeGame.isQuestionRevealed;
  // Word games always allow buzzing. Feud only if question is hidden.
  const isBuzzerActive = isQuestionHidden || activeGame.type === 'WORD';
  
  let buttonColor = team === 'A' ? 'bg-blue-600' : 'bg-pink-600';
  let buttonText = "ZİLE BAS";
  let disabled = false;

  if (activeGame.buzzerWinner) {
     if (activeGame.buzzerWinner.playerId === myId) {
        buttonColor = 'bg-green-500 animate-pulse';
        buttonText = "SEN BASTIN!";
     } else {
        buttonColor = 'bg-gray-700';
        buttonText = `${activeGame.buzzerWinner.playerName} BASTI`;
        disabled = true;
     }
  } else if (!isBuzzerActive) {
      buttonColor = 'bg-gray-800';
      buttonText = "BEKLE";
      disabled = true;
  }

  return (
    <div className="h-full bg-gray-900 flex flex-col items-center justify-center relative overflow-hidden">
       <div className="absolute inset-0 bg-gray-800/20 pointer-events-none"></div>
       <div className="absolute top-4 right-4 z-20 flex items-center gap-2 text-xs font-mono opacity-50 text-white">
           {isOnline ? <Wifi size={14} className="text-green-500"/> : <WifiOff size={14} className="text-red-500"/>}
       </div>
       <button
          onClick={handleBuzzerClick}
          disabled={disabled}
          className={`relative z-10 w-64 h-64 rounded-full border-8 border-white/10 shadow-2xl flex flex-col items-center justify-center transition-transform active:scale-95 ${buttonColor} ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 cursor-pointer'}`}
       >
          <Hand size={60} className="text-white mb-2"/>
          <span className="text-3xl font-display text-white">{buttonText}</span>
       </button>
       {activeGame.type === 'WORD' && <div className="mt-8 text-white text-center font-bold px-4 bg-purple-900/50 p-2 rounded">KELİMEYİ BİLİYORSAN BAS!</div>}
    </div>
  );
};

export default PlayerRemote;