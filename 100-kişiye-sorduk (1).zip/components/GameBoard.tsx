import React from 'react';
import { GameRound, Answer, Team, Player } from '../types';
import { Hand, Trophy } from 'lucide-react';

interface GameBoardProps {
  game: GameRound | null;
  showStrikeOverlay: boolean;
  teams: { A: Team, B: Team };
  players: Player[];
  gamePhase: 'LOBBY' | 'GAME';
}

const GameBoard: React.FC<GameBoardProps> = ({ game, showStrikeOverlay, teams, players, gamePhase }) => {
  
  // -- LOBBY SCREEN --
  if (gamePhase === 'LOBBY') {
     return (
        <div className="w-full h-full bg-game-blue flex flex-col items-center justify-center p-8 text-center">
           <h1 className="text-8xl font-display text-game-yellow mb-8 drop-shadow-lg">YARIŞMA</h1>
           <h2 className="text-4xl text-white mb-12">OYUNCULAR BEKLENİYOR...</h2>
           <div className="grid grid-cols-2 gap-20 w-full max-w-5xl">
              <div className="text-white">
                 <h3 className="text-5xl font-bold mb-6 text-blue-400">{teams.A.name}</h3>
                 <div className="text-2xl">{players.filter(p=>p.team==='A').length} Oyuncu</div>
              </div>
              <div className="text-white">
                 <h3 className="text-5xl font-bold mb-6 text-pink-400">{teams.B.name}</h3>
                 <div className="text-2xl">{players.filter(p=>p.team==='B').length} Oyuncu</div>
              </div>
           </div>
        </div>
     );
  }

  if (!game) {
    return (
      <div className="w-full h-full bg-black flex flex-col items-center justify-center p-4">
        <h1 className="text-6xl text-game-yellow font-display mb-12">PUAN DURUMU</h1>
        <div className="flex gap-24 items-center">
           <div className="text-center">
              <div className="text-6xl text-white font-bold mb-4">{teams.A.name}</div>
              <div className="text-9xl text-blue-500 font-display">{teams.A.score}</div>
           </div>
           <div className="h-40 w-1 bg-gray-700"></div>
           <div className="text-center">
              <div className="text-6xl text-white font-bold mb-4">{teams.B.name}</div>
              <div className="text-9xl text-pink-500 font-display">{teams.B.score}</div>
           </div>
        </div>
      </div>
    );
  }

  // --- STAGE 1: FEUD ---
  if (game.type === 'FEUD') {
    const isQuestionHidden = !game.isQuestionRevealed;
    const displayAnswers = [...game.answers];
    while (displayAnswers.length < 6) displayAnswers.push({ id: `e-${displayAnswers.length}`, text: '', score: 0, revealed: false });

    return (
      <div className="w-full h-full bg-gradient-to-b from-blue-900 to-black p-6 flex flex-col items-center relative overflow-hidden">
         {/* Question */}
         <div className="w-full max-w-5xl bg-blue-950 border-4 border-yellow-500 rounded-2xl p-6 text-center shadow-2xl mb-8 min-h-[120px] flex items-center justify-center z-10">
            {isQuestionHidden ? (
               <span className="text-4xl text-yellow-400 font-display animate-pulse">SORU OKUNUYOR...</span>
            ) : (
               <h2 className="text-4xl text-white font-bold uppercase">{game.question}</h2>
            )}
         </div>

         {/* Scores */}
         <div className="absolute top-1/2 -translate-y-1/2 left-10 hidden xl:block">
            <div className={`p-6 rounded-xl border-4 ${game.activeTeam === 'A' ? 'bg-blue-800 border-yellow-400 scale-110 shadow-lg' : 'bg-blue-900/50 border-blue-600'}`}>
               <div className="text-3xl text-white font-bold mb-2">{teams.A.name}</div>
               <div className="text-7xl text-white font-display">{teams.A.score}</div>
            </div>
         </div>
         <div className="absolute top-1/2 -translate-y-1/2 right-10 hidden xl:block">
            <div className={`p-6 rounded-xl border-4 ${game.activeTeam === 'B' ? 'bg-pink-800 border-yellow-400 scale-110 shadow-lg' : 'bg-pink-900/50 border-pink-600'}`}>
               <div className="text-3xl text-white font-bold mb-2">{teams.B.name}</div>
               <div className="text-7xl text-white font-display">{teams.B.score}</div>
            </div>
         </div>

         {/* Grid */}
         <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Buzzer Overlay */}
            {isQuestionHidden && (
               <div className="absolute inset-0 z-50 flex items-center justify-center gap-12 bg-black/60 backdrop-blur-sm">
                  <div className={`w-64 h-64 rounded-full border-8 flex flex-col items-center justify-center ${game.buzzerWinner?.team === 'A' ? 'bg-green-600 border-white scale-110' : 'bg-blue-800 border-blue-500 opacity-50'}`}>
                     <span className="text-4xl text-white font-display">{teams.A.name}</span>
                     {game.buzzerWinner?.team === 'A' && <span className="text-white font-bold mt-2">{game.buzzerWinner.playerName}</span>}
                  </div>
                  <div className={`w-64 h-64 rounded-full border-8 flex flex-col items-center justify-center ${game.buzzerWinner?.team === 'B' ? 'bg-green-600 border-white scale-110' : 'bg-pink-800 border-pink-500 opacity-50'}`}>
                     <span className="text-4xl text-white font-display">{teams.B.name}</span>
                     {game.buzzerWinner?.team === 'B' && <span className="text-white font-bold mt-2">{game.buzzerWinner.playerName}</span>}
                  </div>
               </div>
            )}
            
            {displayAnswers.map((ans, i) => (
               <div key={i} className="h-24 perspective-1000">
                  <div className={`relative w-full h-full transition-all duration-700 transform-style-3d ${ans.revealed ? 'rotate-x-180' : ''}`}>
                     <div className="absolute inset-0 backface-hidden bg-gradient-to-br from-blue-800 to-blue-950 border-2 border-blue-400 rounded-lg flex items-center justify-center shadow-lg">
                        <span className="text-4xl font-display text-blue-200 opacity-20">{i+1}</span>
                     </div>
                     <div className="absolute inset-0 backface-hidden rotate-x-180 bg-gradient-to-r from-blue-600 to-blue-500 border-2 border-white rounded-lg flex items-center overflow-hidden">
                        <div className="flex-grow pl-6 text-2xl font-bold text-white uppercase truncate">{ans.text}</div>
                        <div className="w-20 h-full bg-yellow-500 flex items-center justify-center text-3xl font-display text-black border-l-2 border-white">{ans.score}</div>
                     </div>
                  </div>
               </div>
            ))}
         </div>

         {/* Total Round Score */}
         <div className="mt-8">
             <div className="bg-blue-900 border-2 border-blue-400 px-12 py-4 rounded-lg">
                <span className="text-2xl text-white mr-4">TOPLAM:</span>
                <span className="text-5xl text-yellow-400 font-display">{game.totalPoints}</span>
             </div>
         </div>

         {/* Strikes */}
         {showStrikeOverlay && (
            <div className="absolute inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md animate-pop">
               <div className="text-[25rem] font-display text-red-600 drop-shadow-[0_0_100px_rgba(220,38,38,1)] leading-none select-none">X</div>
            </div>
         )}
      </div>
    );
  }

  // --- STAGE 2: NUMERIC ---
  if (game.type === 'NUMERIC') {
    // Sort guesses by diff if revealed
    const sortedGuesses = game.isNumericResultRevealed 
       ? [...game.numericGuesses].sort((a,b) => (a.diff || 0) - (b.diff || 0))
       : game.numericGuesses;

    return (
       <div className="w-full h-full bg-gray-900 flex flex-col p-8">
          <div className="text-center mb-8">
             <span className="bg-yellow-500 text-black px-4 py-1 rounded font-bold uppercase tracking-widest mb-4 inline-block">SAYISAL TAHMİN (50 PUAN)</span>
             <h2 className="text-5xl text-white font-bold leading-tight max-w-5xl mx-auto">{game.question}</h2>
          </div>

          <div className="flex-grow flex items-center justify-center gap-8 flex-wrap content-center">
             {sortedGuesses.map((g, i) => {
                const isWinner = i === 0 && game.isNumericResultRevealed;
                return (
                   <div key={i} className={`relative min-w-[200px] p-6 rounded-xl border-4 text-center transition-all duration-500 ${isWinner ? 'bg-green-600 border-white scale-125 z-10 shadow-[0_0_50px_rgba(34,197,94,0.6)]' : 'bg-gray-800 border-gray-600'}`}>
                      {isWinner && <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-yellow-400"><Trophy size={48} fill="currentColor"/></div>}
                      <div className="text-xl text-gray-300 font-bold mb-2">{g.playerName}</div>
                      <div className="text-5xl font-mono text-white">{g.guess}</div>
                      {game.isNumericResultRevealed && (
                         <div className="mt-2 text-sm font-bold bg-black/30 rounded py-1">Fark: {g.diff}</div>
                      )}
                   </div>
                )
             })}
          </div>
          
          {game.isNumericResultRevealed && (
             <div className="text-center mt-8 animate-pop">
                <div className="text-2xl text-gray-400 mb-2">DOĞRU CEVAP</div>
                <div className="text-8xl font-display text-yellow-400">{game.correctNumber}</div>
             </div>
          )}
       </div>
    );
  }

  // --- STAGE 3: WORD ---
  if (game.type === 'WORD') {
     return (
        <div className="w-full h-full bg-purple-900 flex flex-col items-center justify-center p-8">
           <div className="mb-12 text-center">
              <span className="bg-pink-500 text-white px-4 py-1 rounded font-bold uppercase tracking-widest mb-4 inline-block">KELİME ETABI</span>
              <div className="text-9xl font-display text-white mt-4">{game.wordCurrentValue} <span className="text-4xl">PUAN</span></div>
           </div>
           
           <div className="text-2xl text-purple-200 mb-8 max-w-4xl text-center">{game.question}</div>

           <div className="flex flex-wrap justify-center gap-4 max-w-6xl">
              {game.wordPuzzle.map((char, i) => (
                 <div key={i} className={`w-20 h-24 md:w-24 md:h-32 flex items-center justify-center text-6xl font-display rounded-lg border-b-8 shadow-xl transition-all ${char ? 'bg-white text-purple-900 border-gray-300 transform -translate-y-2' : 'bg-purple-800 border-purple-950 text-transparent'}`}>
                    {char || '?'}
                 </div>
              ))}
           </div>
           
           {/* If someone buzzed */}
           {game.buzzerWinner && (
              <div className="absolute bottom-10 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-12 py-4 rounded-full text-3xl font-bold animate-pulse shadow-2xl z-50">
                 {game.buzzerWinner.playerName} TAHMİN EDİYOR!
              </div>
           )}
        </div>
     );
  }

  return null;
};

export default GameBoard;