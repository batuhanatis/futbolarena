import React from 'react';
import { GameRound, Team } from '../types';
import { ExternalLink, CheckCircle2, Eye, Play } from 'lucide-react';

interface GameHostProps {
  game: GameRound | null;
  teams: { A: Team, B: Team };
  roundInfo?: { current: number, total: number };
  
  // Handlers
  onRevealAnswer: (id: string) => void;
  onRevealNumericWinner: () => void;
  onRevealLetter: () => void;
  onWordSolveSuccess: (teamId: 'A' | 'B') => void;
  
  onStrike: () => void;
  onResetStrikes: () => void;
  onEndRound: (winnerId: 'A' | 'B' | null) => void;
  openBoardWindow: () => void;
  onSetTurn: (teamId: 'A' | 'B') => void;
}

const GameHost: React.FC<GameHostProps> = ({ 
  game, teams, roundInfo,
  onRevealAnswer, onRevealNumericWinner, onRevealLetter, onWordSolveSuccess,
  onStrike, onResetStrikes, onEndRound, openBoardWindow, onSetTurn
}) => {
  if (!game) {
    return (
      <div className="p-8 text-center text-gray-400 flex flex-col items-center justify-center h-full">
        <h2 className="text-2xl font-bold mb-2">Şu an aktif bir soru yok.</h2>
        <button onClick={openBoardWindow} className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-2 mt-4"><ExternalLink size={20}/> Ekranı Aç</button>
      </div>
    );
  }

  return (
    <div className="h-full bg-gray-100 p-6 overflow-y-auto">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="bg-white p-4 rounded-xl shadow-md border-l-4 border-game-blue sticky top-0 z-10">
            <div className="flex justify-between items-center">
               <div className="flex items-center gap-2">
                  <span className="bg-game-yellow text-black px-2 py-0.5 rounded text-xs font-bold uppercase">{game.type}</span>
                  <span className="text-gray-500 font-bold">{roundInfo?.current}/{roundInfo?.total}</span>
               </div>
               <div className="font-display text-xl bg-game-blue text-white px-3 py-1 rounded">{game.type === 'WORD' ? game.wordCurrentValue : game.totalPoints} Puan</div>
            </div>
            <p className="text-xl font-bold text-gray-800 mt-2">{game.question}</p>
        </div>

        {/* --- STAGE 1: FEUD CONTROLS --- */}
        {game.type === 'FEUD' && (
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-white rounded-xl shadow-md overflow-hidden">
                 <ul className="divide-y divide-gray-100">
                    {game.answers.map((ans, idx) => (
                       <li key={ans.id} className="flex justify-between p-4 hover:bg-gray-50 cursor-pointer" onClick={() => onRevealAnswer(ans.id)}>
                          <span className={`${ans.revealed ? 'text-green-600 font-bold' : 'text-gray-600'}`}>{idx+1}. {ans.text}</span>
                          <span className="font-bold">{ans.score}</span>
                       </li>
                    ))}
                 </ul>
              </div>
              <div className="space-y-4">
                 <div className="bg-white p-4 rounded shadow">
                    <h3 className="font-bold text-sm mb-2 text-gray-500">ZİL DURUMU</h3>
                    {game.buzzerWinner ? (
                       <div className={`p-4 rounded text-white font-bold text-center ${game.buzzerWinner.team === 'A' ? 'bg-blue-600' : 'bg-pink-600'}`}>
                          {game.buzzerWinner.playerName} ({game.buzzerWinner.team})
                       </div>
                    ) : <div className="text-center text-gray-400 py-4">Zil bekleniyor...</div>}
                 </div>
                 <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => onSetTurn('A')} className="bg-blue-100 text-blue-800 py-2 rounded font-bold hover:bg-blue-200">Takım A</button>
                    <button onClick={() => onSetTurn('B')} className="bg-pink-100 text-pink-800 py-2 rounded font-bold hover:bg-pink-200">Takım B</button>
                 </div>
                 <button onClick={onStrike} className="w-full bg-red-600 text-white py-4 rounded font-bold hover:bg-red-700">YANLIŞ (X)</button>
              </div>
           </div>
        )}

        {/* --- STAGE 2: NUMERIC CONTROLS --- */}
        {game.type === 'NUMERIC' && (
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow p-4">
                 <h3 className="font-bold mb-4 border-b pb-2">Gelen Tahminler (Doğru: {game.correctNumber})</h3>
                 <div className="space-y-2 max-h-96 overflow-y-auto">
                    {game.numericGuesses.map((g, i) => (
                       <div key={i} className="flex justify-between items-center bg-gray-50 p-2 rounded">
                          <span className={`font-bold ${g.team === 'A' ? 'text-blue-600' : 'text-pink-600'}`}>{g.playerName}</span>
                          <span className="font-mono text-lg">{g.guess}</span>
                          {game.isNumericResultRevealed && g.diff !== undefined && (
                             <span className="text-xs bg-gray-200 px-2 py-1 rounded">Fark: {g.diff}</span>
                          )}
                       </div>
                    ))}
                 </div>
              </div>
              <div className="space-y-4">
                 <div className="bg-blue-50 p-4 rounded border border-blue-200">
                    <p className="text-sm text-blue-800 mb-2">Herkes tahmin yaptıktan sonra sonucu açın. Sistem en yakını bulup 50 puan verecek.</p>
                    <button onClick={onRevealNumericWinner} disabled={game.isNumericResultRevealed} className="w-full bg-blue-600 text-white py-3 rounded font-bold hover:bg-blue-700 disabled:opacity-50">
                       SONUCU GÖSTER & PUANI VER
                    </button>
                 </div>
              </div>
           </div>
        )}

        {/* --- STAGE 3: WORD CONTROLS --- */}
        {game.type === 'WORD' && (
           <div className="grid grid-cols-1 gap-6">
              <div className="bg-white p-6 rounded-xl shadow text-center">
                 <div className="flex justify-center gap-2 mb-6 flex-wrap">
                    {game.wordPuzzle.map((char, i) => (
                       <div key={i} className={`w-10 h-12 flex items-center justify-center border rounded font-bold text-xl ${char ? 'bg-white text-black border-black' : 'bg-gray-200 border-gray-300'}`}>
                          {char || '_'}
                       </div>
                    ))}
                 </div>
                 <div className="flex justify-center gap-4">
                    <button onClick={onRevealLetter} className="px-6 py-3 bg-purple-600 text-white font-bold rounded hover:bg-purple-700 flex items-center gap-2">
                       <Eye size={20}/> Harf Aç (-10 Puan)
                    </button>
                 </div>
              </div>

              {/* Buzzer Handling for Word Game */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="bg-white p-4 rounded shadow">
                    <h3 className="font-bold text-sm mb-2 text-gray-500">ZİL (TAHMİN İÇİN)</h3>
                    {game.buzzerWinner ? (
                       <div className={`p-4 rounded text-white font-bold text-center mb-4 ${game.buzzerWinner.team === 'A' ? 'bg-blue-600' : 'bg-pink-600'}`}>
                          {game.buzzerWinner.playerName} BİLDİ Mİ?
                       </div>
                    ) : <div className="text-center text-gray-400 py-4">Tahmin için zil bekleniyor...</div>}
                 </div>
                 
                 <div className="bg-white p-4 rounded shadow space-y-2">
                    <p className="text-sm font-bold text-gray-500 text-center mb-2">DOĞRU BİLİRSE:</p>
                    <button onClick={() => onWordSolveSuccess('A')} className="w-full bg-blue-600 text-white py-3 rounded font-bold hover:bg-blue-700">Takım A Kazandı</button>
                    <button onClick={() => onWordSolveSuccess('B')} className="w-full bg-pink-600 text-white py-3 rounded font-bold hover:bg-pink-700">Takım B Kazandı</button>
                 </div>
              </div>
           </div>
        )}

        {/* Global Controls */}
        <div className="mt-8 pt-6 border-t border-gray-300">
           <button onClick={() => onEndRound(null)} className="w-full bg-gray-800 text-white py-4 rounded-lg font-bold hover:bg-gray-700">
             Sıradaki Soruya Geç / Turu Bitir
           </button>
        </div>

      </div>
    </div>
  );
};

export default GameHost;