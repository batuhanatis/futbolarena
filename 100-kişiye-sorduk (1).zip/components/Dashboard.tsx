import React, { useState } from 'react';
import { GameQuestion, Team, QuestionType } from '../types';
import { Trash2, Play, Plus, Save, Trophy, RotateCcw, CheckSquare, Square, Edit, Hash, Type as TypeIcon, List, Zap } from 'lucide-react';

interface DashboardProps {
  allQuestions: GameQuestion[];
  teams: { A: Team, B: Team };
  onStartGame: (questions: GameQuestion[]) => void;
  onStartFullTournament: () => void;
  onSaveQuestion: (q: GameQuestion) => void;
  onDeleteQuestion: (id: string) => void;
  onUpdateTeamName: (id: 'A' | 'B', name: string) => void;
  onResetTournament: () => void;
}

const safeUUID = () => {
    try {
        if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
           return crypto.randomUUID();
        }
        return 'q-' + Math.random().toString(36).substr(2, 9);
    } catch (e) {
        return 'q-' + Math.random().toString(36).substr(2, 9);
    }
};

const Dashboard: React.FC<DashboardProps> = ({ 
  allQuestions, 
  teams,
  onStartGame,
  onStartFullTournament,
  onSaveQuestion, 
  onDeleteQuestion,
  onUpdateTeamName,
  onResetTournament
}) => {
  const [activeTab, setActiveTab] = useState<QuestionType>('FEUD');
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Selection State (Independent per tab, but for simplicity, we manage global selection and filter on start)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Form State
  const [questionText, setQuestionText] = useState('');
  // Feud Answers
  const [feudAnswers, setFeudAnswers] = useState<{ text: string; score: number }[]>(Array(6).fill({text: '', score: 0}));
  // Numeric
  const [numericCorrect, setNumericCorrect] = useState<number>(0);
  // Word
  const [wordCorrect, setWordCorrect] = useState<string>('');

  const filteredQuestions = allQuestions.filter(q => q.type === activeTab);

  const startEditing = (q?: GameQuestion) => {
    setIsEditing(true);
    if (q) {
      setEditingId(q.id);
      setQuestionText(q.question);
      if (q.type === 'FEUD' && q.answers) setFeudAnswers(q.answers);
      if (q.type === 'NUMERIC') setNumericCorrect(q.correctNumber || 0);
      if (q.type === 'WORD') setWordCorrect(q.correctWord || '');
    } else {
      setEditingId(null);
      setQuestionText('');
      setFeudAnswers(Array(6).fill({text: '', score: 0}));
      setNumericCorrect(0);
      setWordCorrect('');
    }
  };

  const handleSave = () => {
    if (!questionText.trim()) return alert("Soru metni gerekli.");

    const newQ: GameQuestion = {
      id: editingId || safeUUID(),
      type: activeTab,
      question: questionText,
      createdAt: Date.now()
    };

    if (activeTab === 'FEUD') {
      newQ.answers = feudAnswers;
    } else if (activeTab === 'NUMERIC') {
      newQ.correctNumber = numericCorrect;
    } else if (activeTab === 'WORD') {
      newQ.correctWord = wordCorrect.toUpperCase();
    }

    onSaveQuestion(newQ);
    setIsEditing(false);
  };

  const toggleSelection = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedIds(newSet);
  };

  const handlePlaySelected = () => {
    const selected = allQuestions.filter(q => selectedIds.has(q.id) && q.type === activeTab);
    if (selected.length === 0) return alert("Bu etap için soru seçmediniz.");
    if (selected.length > 5) return alert("Her etap için en fazla 5 soru seçebilirsiniz.");
    
    onStartGame(selected);
    // Clear selection after start? Maybe keep it.
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl h-full overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Yönetim Paneli</h1>
        <div className="flex gap-2">
           <button onClick={onResetTournament} className="bg-red-900/50 hover:bg-red-800 text-red-200 py-2 px-4 rounded-lg flex items-center gap-2 border border-red-800">
             <RotateCcw size={18}/> Sıfırla
           </button>
           <button onClick={() => startEditing()} className="bg-game-yellow text-black hover:bg-yellow-400 font-bold py-2 px-4 rounded-lg flex items-center gap-2">
             <Plus size={20}/> Yeni Soru
           </button>
        </div>
      </div>

      {/* Main Action Area */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-700 p-6 rounded-xl border border-gray-600 mb-8 flex justify-between items-center shadow-lg">
         <div>
            <h2 className="text-2xl font-bold text-white mb-2">Hızlı Yarışma Başlat</h2>
            <p className="text-gray-300">Sistem havuzdan otomatik olarak 5 Soru (Feud) + 5 Soru (Sayısal) + 5 Soru (Kelime) seçer ve yarışmayı sırayla başlatır.</p>
         </div>
         <button onClick={onStartFullTournament} className="bg-green-600 hover:bg-green-500 text-white font-bold py-4 px-8 rounded-xl shadow-lg flex items-center gap-3 transform hover:scale-105 transition-all text-xl">
             <Zap size={28} className="text-yellow-300"/> YARIŞMAYI BAŞLAT (TAM TUR)
         </button>
      </div>

      {/* Teams */}
      <div className="grid grid-cols-2 gap-6 mb-8">
         {/* Team A & B Inputs same as before */}
         <div className="bg-blue-900/40 border border-blue-500/30 p-4 rounded-xl flex justify-between items-center">
            <div><div className="text-blue-300 text-xs font-bold uppercase">Takım 1</div><input className="bg-transparent text-white font-bold text-xl w-32 outline-none" value={teams.A.name} onChange={e => onUpdateTeamName('A', e.target.value)}/></div>
            <div className="text-4xl font-display text-white">{teams.A.score}</div>
         </div>
         <div className="bg-pink-900/40 border border-pink-500/30 p-4 rounded-xl flex justify-between items-center">
            <div><div className="text-pink-300 text-xs font-bold uppercase">Takım 2</div><input className="bg-transparent text-white font-bold text-xl w-32 outline-none" value={teams.B.name} onChange={e => onUpdateTeamName('B', e.target.value)}/></div>
            <div className="text-4xl font-display text-white">{teams.B.score}</div>
         </div>
      </div>

      {/* Manual Selection Tabs */}
      <h3 className="text-gray-400 font-bold mb-4 uppercase text-sm tracking-wider border-b border-gray-700 pb-2">Manuel Soru Yönetimi</h3>
      <div className="flex gap-4 mb-6 border-b border-gray-700 pb-1">
         <button onClick={() => setActiveTab('FEUD')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-bold transition ${activeTab === 'FEUD' ? 'bg-game-blue text-white border-b-2 border-game-yellow' : 'text-gray-400 hover:text-white'}`}>
            <List size={18}/> 1. Etap (Feud)
         </button>
         <button onClick={() => setActiveTab('NUMERIC')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-bold transition ${activeTab === 'NUMERIC' ? 'bg-game-blue text-white border-b-2 border-game-yellow' : 'text-gray-400 hover:text-white'}`}>
            <Hash size={18}/> 2. Etap (Sayısal)
         </button>
         <button onClick={() => setActiveTab('WORD')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-bold transition ${activeTab === 'WORD' ? 'bg-game-blue text-white border-b-2 border-game-yellow' : 'text-gray-400 hover:text-white'}`}>
            <TypeIcon size={18}/> 3. Etap (Kelime)
         </button>
      </div>

      {/* Bulk Action for Manual */}
      {selectedIds.size > 0 && !isEditing && (
         <div className="bg-gray-800 p-4 rounded-lg flex justify-between items-center mb-6 border border-gray-600">
            <div className="font-bold text-white">{selectedIds.size} Soru Seçildi (Manuel)</div>
            <div className="flex gap-3">
               <button onClick={() => setSelectedIds(new Set())} className="text-gray-300 hover:text-white">Temizle</button>
               <button onClick={handlePlaySelected} className="bg-white text-gray-900 font-bold px-4 py-2 rounded flex items-center gap-2"><Play size={16}/> Sadece Seçilenleri Oynat</button>
            </div>
         </div>
      )}

      {/* Edit Form */}
      {isEditing ? (
         <div className="bg-white rounded-xl p-6 text-gray-800">
            <h3 className="font-bold text-lg mb-4">{editingId ? 'Düzenle' : 'Yeni Soru'} - {activeTab}</h3>
            <div className="mb-4">
               <label className="block text-sm font-bold mb-1">Soru Metni</label>
               <input className="w-full border p-2 rounded" value={questionText} onChange={e => setQuestionText(e.target.value)} />
            </div>
            
            {activeTab === 'FEUD' && (
               <div className="grid gap-2">
                  <label className="font-bold">Cevaplar (6 Adet)</label>
                  {feudAnswers.map((ans, idx) => (
                     <div key={idx} className="flex gap-2">
                        <input className="border p-2 rounded flex-grow" placeholder={`Cevap ${idx+1}`} value={ans.text} onChange={e => {
                           const n = [...feudAnswers]; n[idx].text = e.target.value; setFeudAnswers(n);
                        }}/>
                        <input className="border p-2 rounded w-20" type="number" placeholder="Puan" value={ans.score} onChange={e => {
                           const n = [...feudAnswers]; n[idx].score = parseInt(e.target.value)||0; setFeudAnswers(n);
                        }}/>
                     </div>
                  ))}
               </div>
            )}
            
            {activeTab === 'NUMERIC' && (
               <div className="mb-4">
                  <label className="block text-sm font-bold mb-1">Doğru Sayısal Cevap</label>
                  <input type="number" className="w-full border p-2 rounded" value={numericCorrect} onChange={e => setNumericCorrect(parseInt(e.target.value))} />
               </div>
            )}

            {activeTab === 'WORD' && (
               <div className="mb-4">
                  <label className="block text-sm font-bold mb-1">Doğru Kelime/Cümle</label>
                  <input className="w-full border p-2 rounded uppercase" value={wordCorrect} onChange={e => setWordCorrect(e.target.value)} />
               </div>
            )}

            <div className="flex justify-end gap-3 mt-6">
               <button onClick={() => setIsEditing(false)} className="px-4 py-2 text-gray-500">İptal</button>
               <button onClick={handleSave} className="bg-green-600 text-white px-6 py-2 rounded font-bold">Kaydet</button>
            </div>
         </div>
      ) : (
         // List Questions
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pb-20">
            {filteredQuestions.map(q => {
               const isSel = selectedIds.has(q.id);
               return (
                  <div key={q.id} onClick={() => toggleSelection(q.id)} className={`bg-white rounded-lg p-4 cursor-pointer border-2 transition relative group ${isSel ? 'border-game-yellow ring-2 ring-game-yellow/50' : 'border-transparent hover:border-blue-300'}`}>
                     <div className="absolute top-2 right-2 flex gap-2">
                        <button onClick={(e) => { e.stopPropagation(); startEditing(q); }} className="p-1 text-gray-400 hover:text-blue-600"><Edit size={16}/></button>
                        <button onClick={(e) => { e.stopPropagation(); onDeleteQuestion(q.id); }} className="p-1 text-gray-400 hover:text-red-600"><Trash2 size={16}/></button>
                     </div>
                     <div className="mb-2">
                        {isSel ? <CheckSquare className="text-game-blue"/> : <Square className="text-gray-300"/>}
                     </div>
                     <p className="text-gray-800 font-bold line-clamp-3">{q.question}</p>
                     <div className="mt-2 text-xs text-gray-500 font-mono bg-gray-100 p-1 rounded inline-block">
                        {q.type === 'FEUD' && '6 Cevap'}
                        {q.type === 'NUMERIC' && `Cevap: ${q.correctNumber}`}
                        {q.type === 'WORD' && `Cevap: ${q.correctWord}`}
                     </div>
                  </div>
               );
            })}
         </div>
      )}
    </div>
  );
};

export default Dashboard;