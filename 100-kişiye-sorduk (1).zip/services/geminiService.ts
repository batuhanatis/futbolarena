import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSurveyQuestion = async (topic?: string): Promise<{ question: string; answers: { text: string; score: number }[] }> => {
  const prompt = topic 
    ? `Topic: ${topic}. Generate a "Family Feud" style survey question in Turkish related to this topic.`
    : `Generate a random, popular "Family Feud" (100 Kişiye Sorduk) style survey question in Turkish.`;

  const instructions = `
    IMPORTANT SCORING RULES:
    1. Provide exactly 6 answers.
    2. Sort the answers from most popular (1st) to least popular (6th) in terms of likelihood, BUT assign scores inversely.
    3. Use ONLY these exact scores in this order:
       - Answer 1 (Most popular/easiest): 5 points
       - Answer 2: 5 points
       - Answer 3: 10 points
       - Answer 4: 15 points
       - Answer 5: 25 points
       - Answer 6 (Least popular/hardest): 40 points
    Total score must be 100.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `${prompt} ${instructions}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          question: {
            type: Type.STRING,
            description: "The survey question in Turkish",
          },
          answers: {
            type: Type.ARRAY,
            description: "List of 6 answers with specific scores [5, 5, 10, 15, 25, 40]",
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING, description: "Answer text in Turkish" },
                score: { type: Type.INTEGER, description: "Score for this answer" }
              },
              required: ["text", "score"]
            }
          }
        },
        required: ["question", "answers"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(text);
};