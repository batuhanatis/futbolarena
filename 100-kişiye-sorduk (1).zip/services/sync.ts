import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onValue, push, onChildAdded, remove } from 'firebase/database';
import { GameState } from '../types';

// ==================================================================================
// 🔥 FIREBASE AYARLARI 🔥
// ==================================================================================
const firebaseConfig = {
  apiKey: "AIzaSyDqYa8f9ssrfkSFtA2VwBkGG09WF0hrxic",
  authDomain: "futbolarena-9c12c.firebaseapp.com",
  projectId: "futbolarena-9c12c",
  storageBucket: "futbolarena-9c12c.firebasestorage.app",
  messagingSenderId: "1010247499418",
  appId: "1:1010247499418:web:11d75f02f49c1a658a2923",
  measurementId: "G-1PWYG49MTV",
  // Realtime Database URL
  databaseURL: "https://futbolarena-9c12c-default-rtdb.firebaseio.com/"
};

class GameSyncService {
  private db: any = null;
  private channel: BroadcastChannel | null = null;
  private mode: 'FIREBASE' | 'LOCAL' = 'LOCAL';

  constructor() {
    // Config kontrolü
    if (firebaseConfig.apiKey && firebaseConfig.apiKey !== "YOUR_API_KEY") {
      try {
        const app = initializeApp(firebaseConfig);
        try {
            this.db = getDatabase(app);
            this.mode = 'FIREBASE';
            console.log("🔥 Firebase Bağlantısı Başarılı: Online Mod");
        } catch (dbError) {
            console.error("🔥 Firebase Veritabanı Hatası (Service database not available):", dbError);
            console.warn("⚠️ Firebase Import uyuşmazlığı olabilir. Local moda geçiliyor.");
            this.fallbackToLocal();
        }
      } catch (e) {
        console.error("🔥 Firebase Başlatma Hatası:", e);
        this.fallbackToLocal();
      }
    } else {
      this.fallbackToLocal();
    }
  }

  private fallbackToLocal() {
    this.mode = 'LOCAL';
    console.warn("⚠️ Yerel Mod (BroadcastChannel) kullanılıyor. Sadece aynı tarayıcıdaki sekmeler haberleşebilir.");
  }

  // --- HOST METHODS ---

  // Oyun durumunu yayınla
  public publishState(sessionId: string, state: GameState) {
    if (this.mode === 'FIREBASE' && this.db) {
      // Firebase'e yaz
      // Firebase undefined değerleri kabul etmez (Hata: value argument contains undefined).
      // JSON.stringify/parse yöntemi undefined alanları otomatik olarak temizler.
      const cleanState = JSON.parse(JSON.stringify(state));
      set(ref(this.db, `sessions/${sessionId}/state`), cleanState);
    } else {
      // Yerel yayın
      this.getChannel(sessionId).postMessage({ type: 'STATE_UPDATE', payload: state });
    }
  }

  // Oyuncu olaylarını dinle (Katılma, Zil, Tahmin)
  public subscribeToEvents(sessionId: string, callback: (event: any) => void) {
    if (this.mode === 'FIREBASE' && this.db) {
      // Listen for new events added to the list
      const eventsRef = ref(this.db, `sessions/${sessionId}/events`);
      
      // onChildAdded: Listeye yeni bir event eklendiğinde tetiklenir
      return onChildAdded(eventsRef, (snapshot) => {
        const data = snapshot.val();
        if (data) callback(data);
      });
    } else {
      const channel = this.getChannel(sessionId);
      channel.onmessage = (e) => {
        if (e.data && e.data.type !== 'STATE_UPDATE') {
          callback(e.data);
        }
      };
      return () => { channel.close(); this.channel = null; };
    }
  }

  // --- PLAYER METHODS ---

  // Olay gönder (Ben katıldım, Zile bastım vb.)
  public sendEvent(sessionId: string, event: any) {
    if (this.mode === 'FIREBASE' && this.db) {
      // Firebase'de events listesine yeni bir kayıt ekle (push)
      const cleanEvent = JSON.parse(JSON.stringify(event));
      push(ref(this.db, `sessions/${sessionId}/events`), {
        ...cleanEvent,
        timestamp: Date.now()
      });
    } else {
      this.getChannel(sessionId).postMessage(event);
    }
  }

  // Oyun durumunu dinle (Host yayınladığında)
  public subscribeToState(sessionId: string, callback: (state: GameState) => void) {
    if (this.mode === 'FIREBASE' && this.db) {
      const stateRef = ref(this.db, `sessions/${sessionId}/state`);
      return onValue(stateRef, (snapshot) => {
        const data = snapshot.val();
        if (data) callback(data);
      });
    } else {
      const channel = this.getChannel(sessionId);
      channel.onmessage = (e) => {
        if (e.data && e.data.type === 'STATE_UPDATE') {
          callback(e.data.payload);
        }
      };
      return () => { channel.close(); this.channel = null; };
    }
  }

  // --- UTILS ---
  
  public getMode() {
    return this.mode;
  }

  private getChannel(sessionId: string) {
    if (!this.channel) {
      this.channel = new BroadcastChannel(`game_channel_${sessionId}`);
    }
    return this.channel;
  }
}

export const gameSync = new GameSyncService();